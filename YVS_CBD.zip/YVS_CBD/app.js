'use strict';

var SwaggerExpress = require('swagger-express-mw');
var cfenv = require('cfenv');
var express = require('express');
var app = express();
var path = require("path");
app.use('/static', express.static(path.join(__dirname, '/public')))
app.use(express.static(__dirname + '/public'));

module.exports = app; // for testing

var config = {
  appRoot: __dirname // required config
};

SwaggerExpress.create(config, function(err, swaggerExpress) {
  if (err) { throw err; }

  // install middleware
  swaggerExpress.register(app);

  var appEnv = cfenv.getAppEnv();
  var port = appEnv.port;
  var url = appEnv.url;
  app.listen(port);

  if (swaggerExpress.runner.swagger.paths['/projects']) {
	console.log("server starting on " + appEnv.url);  
    console.log('try this:\ncurl ' + appEnv.url + port + '/resources/services/projects');
	console.log('curl ' + appEnv.url + port + '/resources/services/assets');
  }
});
